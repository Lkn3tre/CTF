package com.akasec.idrive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdriveApplicationTests {

	@Test
	void contextLoads() {
	}

}
