package com.akasec.idrive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdriveApplication {
    public static void main(String[] args) {
        SpringApplication.run(IdriveApplication.class, args);
    }
}
